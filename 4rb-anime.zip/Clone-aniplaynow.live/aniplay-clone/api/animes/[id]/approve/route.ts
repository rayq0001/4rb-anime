
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const id = parseInt(params.id);
  const anime = await prisma.anime.update({
    where: { id },
    data: { approved: true },
  });

  return NextResponse.json(anime);
}
