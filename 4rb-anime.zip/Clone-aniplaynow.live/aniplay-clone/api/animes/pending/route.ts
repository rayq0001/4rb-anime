
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function GET() {
  const animes = await prisma.anime.findMany({
    where: { approved: false },
    include: { episodes: true },
  });

  return NextResponse.json(animes);
}
