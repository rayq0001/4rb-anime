import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Image from "next/image";
import Link from "next/link";
import { PlayCircle, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function SchedulePage() {
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  return (
    <div className="container mx-auto pt-6 pl-16 max-w-full">
      <h1 className="text-3xl font-bold mb-6">Anime Schedule</h1>

      <div className="bg-card rounded-lg p-6">
        <Tabs defaultValue="monday">
          <TabsList className="w-full flex mb-6 bg-background">
            {days.map(day => (
              <TabsTrigger
                key={day}
                value={day.toLowerCase()}
                className="flex-1"
              >
                {day}
              </TabsTrigger>
            ))}
          </TabsList>

          {days.map(day => (
            <TabsContent key={day} value={day.toLowerCase()}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {scheduleData[day.toLowerCase()].map((anime) => (
                  <ScheduleAnimeCard key={anime.id} anime={anime} />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}

interface ScheduleAnime {
  id: string;
  title: string;
  image: string;
  releaseTime: string;
  episode: number;
  type: string;
  status: string;
}

const ScheduleAnimeCard = ({ anime }: { anime: ScheduleAnime }) => {
  return (
    <div className="flex gap-4 p-4 bg-background rounded-lg hover:bg-primary/5 transition-colors">
      <div className="relative w-[100px] h-[150px] overflow-hidden rounded-md">
        <Image
          src={anime.image}
          alt={anime.title}
          fill
          className="object-cover"
        />
      </div>

      <div className="flex-1">
        <Link href={`/anime/info/${anime.id}`}>
          <h3 className="font-semibold hover:text-primary transition-colors line-clamp-2 mb-2">
            {anime.title}
          </h3>
        </Link>

        <div className="flex items-center gap-2 mb-2 text-xs text-muted-foreground">
          <CalendarDays size={14} />
          <span>Episode {anime.episode} at {anime.releaseTime}</span>
        </div>

        <Badge variant="outline" className="bg-green-500/20 text-green-300 border-green-800 mb-3">
          {anime.status}
        </Badge>

        <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
          <PlayCircle className="mr-2 h-3 w-3" />
          Watch
        </Button>
      </div>
    </div>
  );
};

// Mock schedule data by day
const scheduleData = {
  monday: [
    {
      id: "185213",
      title: "Mobile Suit Gundam GQuuuuuuX",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx185213-Pv7NliMfSLmk.jpg",
      releaseTime: "18:00 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
    {
      id: "149118",
      title: "Fire Force Season 3",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx149118-FlghR7T9KNfq.jpg",
      releaseTime: "20:30 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
  ],
  tuesday: [
    {
      id: "178680",
      title: "WIND BREAKER Season 2",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx178680-4mYUlJpBGjAw.jpg",
      releaseTime: "19:00 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
    {
      id: "180367",
      title: "WITCH WATCH",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx180367-0W9XJdwkXwKv.jpg",
      releaseTime: "22:30 JST",
      episode: 26,
      type: "TV",
      status: "RELEASING"
    },
  ],
  wednesday: [
    {
      id: "21",
      title: "ONE PIECE",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
      releaseTime: "17:00 JST",
      episode: 1129,
      type: "TV",
      status: "RELEASING"
    },
    {
      id: "179955",
      title: "From Old Country Bumpkin to Master Swordsman",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx179955-HZ4TrxnPpRl9.jpg",
      releaseTime: "21:00 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
  ],
  thursday: [
    {
      id: "167336",
      title: "LAZARUS",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx167336-6oMYQUm2LgXd.png",
      releaseTime: "19:30 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
    {
      id: "174802",
      title: "The Shiunji Family Children",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx174802-rJORNTqw7eUB.jpg",
      releaseTime: "23:00 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
  ],
  friday: [
    {
      id: "185736",
      title: "My Hero Academia: Vigilantes",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx185736-5ug0SXQArEPD.jpg",
      releaseTime: "18:30 JST",
      episode: 13,
      type: "TV",
      status: "RELEASING"
    },
  ],
  saturday: [
    {
      id: "183161",
      title: "The Beginning After the End",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx183161-JUFdX12F3sL6.png",
      releaseTime: "20:00 JST",
      episode: 7,
      type: "TV",
      status: "RELEASING"
    },
  ],
  sunday: [
    {
      id: "180675",
      title: "Apocalypse Hotel",
      image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx180675-Lf1DFcHn5mZR.jpg",
      releaseTime: "19:30 JST",
      episode: 12,
      type: "TV",
      status: "RELEASING"
    },
  ],
};
