"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function SettingsPage() {
  return (
    <div className="container mx-auto pt-6 pl-16 max-w-full">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>

      <div className="max-w-3xl">
        <Tabs defaultValue="appearance">
          <TabsList className="mb-6">
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="playback">Playback</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
          </TabsList>

          <TabsContent value="appearance" className="space-y-6">
            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Theme</h2>
              <RadioGroup defaultValue="dark">
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="light" id="light" />
                  <Label htmlFor="light">Light</Label>
                </div>
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="dark" id="dark" />
                  <Label htmlFor="dark">Dark</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="system" id="system" />
                  <Label htmlFor="system">System</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Interface</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Show Episode Thumbnails</h3>
                    <p className="text-xs text-muted-foreground">Display thumbnails for each episode</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Show Anime Descriptions</h3>
                    <p className="text-xs text-muted-foreground">Display anime descriptions on hover</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Display Episode Progress</h3>
                    <p className="text-xs text-muted-foreground">Show watchtime progress for episodes</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="playback" className="space-y-6">
            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Video Quality</h2>
              <RadioGroup defaultValue="auto">
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="auto" id="auto" />
                  <Label htmlFor="auto">Auto (Recommended)</Label>
                </div>
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="1080p" id="1080p" />
                  <Label htmlFor="1080p">1080p</Label>
                </div>
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="720p" id="720p" />
                  <Label htmlFor="720p">720p</Label>
                </div>
                <div className="flex items-center space-x-2 mb-4">
                  <RadioGroupItem value="480p" id="480p" />
                  <Label htmlFor="480p">480p</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="360p" id="360p" />
                  <Label htmlFor="360p">360p</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Playback Settings</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Autoplay Next Episode</h3>
                    <p className="text-xs text-muted-foreground">Automatically play the next episode</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Skip Intro</h3>
                    <p className="text-xs text-muted-foreground">Automatically skip intro sequences</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Skip Ending</h3>
                    <p className="text-xs text-muted-foreground">Automatically skip ending sequences</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="account" className="space-y-6">
            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Login Status</h2>
              <p className="text-muted-foreground mb-4">You are not currently logged in.</p>
              <button className="bg-purple-600 hover:bg-purple-700 text-white rounded-md px-4 py-2 text-sm font-medium">
                Login / Register
              </button>
            </div>
          </TabsContent>

          <TabsContent value="about" className="space-y-6">
            <div className="bg-card rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">About Aniplay</h2>
              <p className="text-muted-foreground mb-4">
                Aniplay is a platform for watching anime online. Our goal is to provide a seamless anime watching experience.
              </p>
              <p className="text-muted-foreground mb-4">
                Version: 1.0.0
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-purple-400 hover:text-purple-300">Discord</a>
                <a href="#" className="text-purple-400 hover:text-purple-300">Twitter</a>
                <a href="#" className="text-purple-400 hover:text-purple-300">Terms of Service</a>
                <a href="#" className="text-purple-400 hover:text-purple-300">Privacy Policy</a>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
