import { Suspense } from "react";
import HeroSection from "@/components/hero-section";
import AnimeCarousel from "@/components/anime-carousel";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  return (
    <div className="container mx-auto pt-2 pl-16 max-w-full">
      <Suspense fallback={<Skeleton className="w-full h-[500px] rounded-xl" />}>
        <HeroSection />
      </Suspense>

      <div className="space-y-12 mt-10">
        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Featured Anime"
            animeList={featuredAnime}
          />
        </Suspense>

        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Trending Now"
            animeList={trendingAnime}
          />
        </Suspense>

        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Popular This Season"
            animeList={popularThisSeason}
          />
        </Suspense>

        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Most Favorite"
            animeList={mostFavorite}
          />
        </Suspense>

        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Popular Movies"
            animeList={popularMovies}
          />
        </Suspense>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Suspense fallback={<Skeleton className="w-full h-[500px] rounded-xl" />}>
            <div>
              <h2 className="text-2xl font-bold mb-6">Top 10 Anime</h2>
              {/* Top 10 Anime Section */}
            </div>
          </Suspense>

          <Suspense fallback={<Skeleton className="w-full h-[500px] rounded-xl" />}>
            <div>
              <h2 className="text-2xl font-bold mb-6">All Time Popular</h2>
              {/* All Time Popular Section */}
            </div>
          </Suspense>
        </div>

        <Suspense fallback={<Skeleton className="w-full h-[300px] rounded-xl" />}>
          <AnimeCarousel
            title="Next Season"
            animeList={nextSeason}
          />
        </Suspense>
      </div>

      <footer className="mt-16 py-8 border-t border-border">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold">Aniplay</h2>
            <p className="text-sm text-muted-foreground mt-2">
              This site does not store any files on our server, we are linked to the media which is hosted on 3rd party services.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12">
            <div>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">This Season</a></li>
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">Upcoming Season</a></li>
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">Movies</a></li>
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">TV Shows</a></li>
              </ul>
            </div>

            <div>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">Changelog</a></li>
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">DMCA</a></li>
                <li><a href="#" className="text-sm text-muted-foreground hover:text-primary">Privacy</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap justify-between items-center">
          <p className="text-sm text-muted-foreground">© 2025 ANIPLAY | Made by Aniplay Team</p>

          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <a href="#" className="text-muted-foreground hover:text-primary">
              <TwitterIcon className="h-5 w-5" />
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary">
              <RedditIcon className="h-5 w-5" />
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary">
              <DiscordIcon className="h-5 w-5" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Mock data components
const TwitterIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
  </svg>
);

const RedditIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <ellipse cx="12" cy="15" rx="5" ry="3"></ellipse>
    <circle cx="12" cy="13" r="0.5"></circle>
    <circle cx="15" cy="9" r="1.5"></circle>
    <circle cx="9" cy="9" r="1.5"></circle>
  </svg>
);

const DiscordIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="9" cy="12" r="1"></circle>
    <circle cx="15" cy="12" r="1"></circle>
    <path d="M7.5 7.5c3.5-1 5.5-1 9 0"></path>
    <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
    <path d="M15.5 17c0 1 1.5 3 2 3 1.5 0 2.5-1.5 2.5-1.5l-1.5-2.5c-1 0-3 1-3 1z"></path>
    <path d="M8.5 17c0 1-1.5 3-2 3-1.5 0-2.5-1.5-2.5-1.5l1.5-2.5c1 0 3 1 3 1z"></path>
  </svg>
);

// Mock data for anime lists
const featuredAnime = [
  {
    id: "104157",
    title: "Rascal Does Not Dream of a Dreaming Girl",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx104157-rk99XI56PaIC.jpg",
    description: "In Fujisawa, where the skies are bright and the seas glisten, Sakuta Azusagawa is in his second year of high school. His blissful days with his girlfriend and upperclassman, Mai Sakurajima, are interrupted with the appearance of his first crush, Shouko Makinohara.",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
];

const trendingAnime = [
  {
    id: "21",
    title: "ONE PIECE",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 1129,
    currentEpisode: 1129
  },
  {
    id: "185213",
    title: "Mobile Suit Gundam GQuuuuuuX",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx185213-Pv7NliMfSLmk.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 25,
    currentEpisode: 7
  },
  {
    id: "174802",
    title: "The Shiunji Family Children",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx174802-rJORNTqw7eUB.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
];

const popularThisSeason = [
  {
    id: "149118",
    title: "Fire Force Season 3",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx149118-FlghR7T9KNfq.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
  {
    id: "167336",
    title: "LAZARUS",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx167336-6oMYQUm2LgXd.png",
    type: "TV",
    status: "RELEASING",
    episodes: 13,
    currentEpisode: 7
  },
  {
    id: "178680",
    title: "WIND BREAKER Season 2",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx178680-4mYUlJpBGjAw.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
];

const mostFavorite = [
  {
    id: "21",
    title: "ONE PIECE",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 1129
  },
  {
    id: "11061",
    title: "Hunter x Hunter (2011)",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx11061-sIpBprNRfzCe.png",
    type: "TV",
    status: "FINISHED",
    episodes: 148
  },
  {
    id: "16498",
    title: "Attack on Titan",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-C6FPmWm59CyP.jpg",
    type: "TV",
    status: "FINISHED",
    episodes: 25
  },
];

const popularMovies = [
  {
    id: "21519",
    title: "Your Name.",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
  {
    id: "20954",
    title: "A Silent Voice",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx20954-q0j9BNwr9yCX.jpg",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
  {
    id: "112151",
    title: "Demon Slayer -Kimetsu no Yaiba- The Movie: Mugen Train",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx112151-1qlQwSW0dQBs.jpg",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
];

const nextSeason = [
  {
    id: "185660",
    title: "DAN DA DAN Season 2",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx185660-xFGQZ0QkXPuu.jpg",
    type: "TV",
    status: "COMING SOON"
  },
  {
    id: "178788",
    title: "Demon Slayer: Kimetsu no Yaiba Infinity Castle",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx178788-ODMWMXTnrgOg.jpg",
    type: "MOVIE",
    status: "COMING SOON"
  },
  {
    id: "171627",
    title: "Chainsaw Man - The Movie: Reze Arc",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx171627-GV824CDiMihn.jpg",
    type: "MOVIE",
    status: "COMING SOON"
  },
];
