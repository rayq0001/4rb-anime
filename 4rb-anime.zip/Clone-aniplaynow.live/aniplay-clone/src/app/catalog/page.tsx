import { Suspense } from "react";
import AnimeGrid from "@/components/anime-grid";
import FilterSidebar from "@/components/filter-sidebar";
import { Skeleton } from "@/components/ui/skeleton";

export default function CatalogPage() {
  return (
    <div className="container mx-auto pt-6 pl-16 max-w-full">
      <h1 className="text-3xl font-bold mb-6">Anime Catalog</h1>

      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-64 shrink-0">
          <Suspense fallback={<Skeleton className="h-[500px] w-full" />}>
            <FilterSidebar />
          </Suspense>
        </div>

        <div className="flex-1">
          <Suspense fallback={<Skeleton className="h-[800px] w-full" />}>
            <AnimeGrid />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
