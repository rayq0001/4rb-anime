import Image from "next/image";
import { PlayCircle, Pause, SkipForward, SkipBack, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MusicPage() {
  return (
    <div className="container mx-auto pt-6 pl-16 max-w-full">
      <h1 className="text-3xl font-bold mb-6">Anime Music</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Tabs defaultValue="popular">
            <TabsList className="mb-6">
              <TabsTrigger value="popular">Popular</TabsTrigger>
              <TabsTrigger value="recent">Recently Added</TabsTrigger>
              <TabsTrigger value="playlists">Playlists</TabsTrigger>
            </TabsList>

            <TabsContent value="popular" className="space-y-4">
              {musicTracks.map((track, index) => (
                <MusicTrackCard
                  key={index}
                  track={track}
                  isPlaying={index === 0}
                />
              ))}
            </TabsContent>

            <TabsContent value="recent" className="space-y-4">
              {musicTracks.slice().reverse().map((track, index) => (
                <MusicTrackCard
                  key={index}
                  track={track}
                  isPlaying={false}
                />
              ))}
            </TabsContent>

            <TabsContent value="playlists" className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {playlists.map((playlist, index) => (
                  <PlaylistCard key={index} playlist={playlist} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <div className="bg-card rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Now Playing</h2>

            <div className="flex flex-col items-center">
              <div className="relative w-full aspect-square mb-6 rounded-md overflow-hidden">
                <Image
                  src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21-tXMN3Y20PIL9.jpg"
                  alt="Album Cover"
                  fill
                  className="object-cover"
                />
              </div>

              <h3 className="text-lg font-semibold mb-1">We Are!</h3>
              <p className="text-sm text-muted-foreground mb-4">ONE PIECE</p>

              <div className="w-full mb-4">
                <Slider defaultValue={[40]} max={100} step={1} className="mb-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1:24</span>
                  <span>3:30</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 mb-6">
                <Button variant="ghost" size="icon" className="rounded-full">
                  <SkipBack className="h-5 w-5" />
                </Button>
                <Button className="h-12 w-12 rounded-full bg-purple-600 hover:bg-purple-700">
                  <Pause className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <SkipForward className="h-5 w-5" />
                </Button>
              </div>

              <div className="flex items-center gap-2 w-full">
                <Volume2 className="h-4 w-4 text-muted-foreground" />
                <Slider defaultValue={[80]} max={100} step={1} className="w-full" />
              </div>
            </div>
          </div>

          <div className="bg-card rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Popular Artists</h2>
            <div className="space-y-4">
              {popularArtists.map((artist, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden">
                    <Image
                      src={artist.image}
                      alt={artist.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">{artist.name}</h3>
                    <p className="text-xs text-muted-foreground">{artist.songs} songs</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface MusicTrack {
  title: string;
  anime: string;
  cover: string;
  duration: string;
  type: string;
}

const MusicTrackCard = ({
  track,
  isPlaying
}: {
  track: MusicTrack;
  isPlaying: boolean;
}) => {
  return (
    <div className={`flex items-center p-3 rounded-lg ${isPlaying ? 'bg-primary/10' : 'hover:bg-primary/5'} transition-colors`}>
      <div className="relative w-12 h-12 rounded overflow-hidden mr-4">
        <Image
          src={track.cover}
          alt={track.title}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          {isPlaying ? (
            <Pause className="h-5 w-5 text-white" />
          ) : (
            <PlayCircle className="h-5 w-5 text-white" />
          )}
        </div>
      </div>

      <div className="flex-1">
        <h3 className="font-semibold text-sm">{track.title}</h3>
        <p className="text-xs text-muted-foreground">{track.anime}</p>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-xs text-muted-foreground">{track.duration}</span>
        <Badge type={track.type} />
      </div>
    </div>
  );
};

const Badge = ({ type }: { type: string }) => {
  let className = "px-2 py-1 text-xs rounded-md font-medium ";

  switch (type.toLowerCase()) {
    case "opening":
      className += "bg-purple-500/20 text-purple-300";
      break;
    case "ending":
      className += "bg-blue-500/20 text-blue-300";
      break;
    case "ost":
      className += "bg-green-500/20 text-green-300";
      break;
    default:
      className += "bg-gray-500/20 text-gray-300";
  }

  return <span className={className}>{type}</span>;
};

interface Playlist {
  name: string;
  cover: string;
  trackCount: number;
}

const PlaylistCard = ({ playlist }: { playlist: Playlist }) => {
  return (
    <div className="bg-background rounded-lg overflow-hidden hover:bg-primary/5 transition-colors">
      <div className="relative w-full aspect-square">
        <Image
          src={playlist.cover}
          alt={playlist.name}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
          <div>
            <h3 className="font-semibold text-white">{playlist.name}</h3>
            <p className="text-xs text-gray-300">{playlist.trackCount} tracks</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Mock data
const musicTracks: MusicTrack[] = [
  {
    title: "We Are!",
    anime: "ONE PIECE",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
    duration: "3:30",
    type: "Opening"
  },
  {
    title: "The Rumbling",
    anime: "Attack on Titan Final Season",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx131681-aQhEll9Z3p4u.jpg",
    duration: "3:42",
    type: "Opening"
  },
  {
    title: "Gurenge",
    anime: "Demon Slayer",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-PEn1CTc93blC.jpg",
    duration: "3:59",
    type: "Opening"
  },
  {
    title: "Kataware Doki",
    anime: "Your Name.",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    duration: "2:48",
    type: "OST"
  },
  {
    title: "Fukashigi no Carte",
    anime: "Rascal Does Not Dream of Bunny Girl Senpai",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101291-Hjz1ToFL5sCq.jpg",
    duration: "4:12",
    type: "Ending"
  },
  {
    title: "KICK BACK",
    anime: "Chainsaw Man",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx127230-FlochcFsyoF4.png",
    duration: "3:15",
    type: "Opening"
  },
  {
    title: "Sparkle",
    anime: "Your Name.",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    duration: "5:54",
    type: "OST"
  },
  {
    title: "Kawaki wo Ameku",
    anime: "Domestic Girlfriend",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx103139-CKp8OHeRJAbS.png",
    duration: "4:10",
    type: "Opening"
  }
];

const playlists: Playlist[] = [
  {
    name: "Epic Battle Themes",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-PEn1CTc93blC.jpg",
    trackCount: 25
  },
  {
    name: "Emotional OSTs",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    trackCount: 18
  },
  {
    name: "Best Openings 2023",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx127230-FlochcFsyoF4.png",
    trackCount: 22
  },
  {
    name: "Relaxing Anime Music",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx20954-q0j9BNwr9yCX.jpg",
    trackCount: 15
  },
  {
    name: "Hype Workout Mix",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx113415-bbBY6dvhjMBs.jpg",
    trackCount: 30
  },
  {
    name: "Studio Ghibli Collection",
    cover: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx199-KrJsrVuS9IoT.jpg",
    trackCount: 40
  }
];

const popularArtists = [
  {
    name: "LISA",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-PEn1CTc93blC.jpg",
    songs: 45
  },
  {
    name: "RADWIMPS",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    songs: 32
  },
  {
    name: "Aimer",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx131681-aQhEll9Z3p4u.jpg",
    songs: 38
  },
  {
    name: "YOASOBI",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx127230-FlochcFsyoF4.png",
    songs: 27
  },
  {
    name: "Hiroyuki Sawano",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-C6FPmWm59CyP.jpg",
    songs: 64
  }
];
