"use client";

import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// We need to install the accordion and checkbox components
import { Badge } from "./ui/badge";

const FilterSidebar = () => {
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedFormats, setSelectedFormats] = useState<string[]>([]);
  const [selectedSeasons, setSelectedSeasons] = useState<string[]>([]);
  const [selectedYears, setSelectedYears] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string[]>([]);

  const toggleGenre = (genre: string) => {
    setSelectedGenres(prev =>
      prev.includes(genre)
        ? prev.filter(item => item !== genre)
        : [...prev, genre]
    );
  };

  const toggleFormat = (format: string) => {
    setSelectedFormats(prev =>
      prev.includes(format)
        ? prev.filter(item => item !== format)
        : [...prev, format]
    );
  };

  const toggleSeason = (season: string) => {
    setSelectedSeasons(prev =>
      prev.includes(season)
        ? prev.filter(item => item !== season)
        : [...prev, season]
    );
  };

  const toggleYear = (year: string) => {
    setSelectedYears(prev =>
      prev.includes(year)
        ? prev.filter(item => item !== year)
        : [...prev, year]
    );
  };

  const toggleStatus = (status: string) => {
    setSelectedStatus(prev =>
      prev.includes(status)
        ? prev.filter(item => item !== status)
        : [...prev, status]
    );
  };

  return (
    <div className="bg-card rounded-lg p-4">
      <h2 className="text-xl font-bold mb-4">Filters</h2>

      {selectedGenres.length > 0 || selectedFormats.length > 0 || selectedSeasons.length > 0 || selectedYears.length > 0 || selectedStatus.length > 0 ? (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2 mb-3">
            {selectedGenres.map(genre => (
              <Badge
                key={genre}
                variant="outline"
                className="bg-primary/10"
                onClick={() => toggleGenre(genre)}
              >
                {genre} ×
              </Badge>
            ))}
            {selectedFormats.map(format => (
              <Badge
                key={format}
                variant="outline"
                className="bg-primary/10"
                onClick={() => toggleFormat(format)}
              >
                {format} ×
              </Badge>
            ))}
            {selectedSeasons.map(season => (
              <Badge
                key={season}
                variant="outline"
                className="bg-primary/10"
                onClick={() => toggleSeason(season)}
              >
                {season} ×
              </Badge>
            ))}
            {selectedYears.map(year => (
              <Badge
                key={year}
                variant="outline"
                className="bg-primary/10"
                onClick={() => toggleYear(year)}
              >
                {year} ×
              </Badge>
            ))}
            {selectedStatus.map(status => (
              <Badge
                key={status}
                variant="outline"
                className="bg-primary/10"
                onClick={() => toggleStatus(status)}
              >
                {status} ×
              </Badge>
            ))}
          </div>
          <button
            className="text-xs text-muted-foreground hover:text-primary"
            onClick={() => {
              setSelectedGenres([]);
              setSelectedFormats([]);
              setSelectedSeasons([]);
              setSelectedYears([]);
              setSelectedStatus([]);
            }}
          >
            Clear all filters
          </button>
        </div>
      ) : null}

      <Accordion type="multiple" defaultValue={["genres", "format", "season"]}>
        <AccordionItem value="genres">
          <AccordionTrigger className="text-sm font-semibold py-3">Genres</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {genres.map(genre => (
                <div key={genre} className="flex items-center space-x-2">
                  <Checkbox
                    id={`genre-${genre}`}
                    checked={selectedGenres.includes(genre)}
                    onCheckedChange={() => toggleGenre(genre)}
                  />
                  <Label
                    htmlFor={`genre-${genre}`}
                    className="text-sm cursor-pointer"
                  >
                    {genre}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="format">
          <AccordionTrigger className="text-sm font-semibold py-3">Format</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {formats.map(format => (
                <div key={format} className="flex items-center space-x-2">
                  <Checkbox
                    id={`format-${format}`}
                    checked={selectedFormats.includes(format)}
                    onCheckedChange={() => toggleFormat(format)}
                  />
                  <Label
                    htmlFor={`format-${format}`}
                    className="text-sm cursor-pointer"
                  >
                    {format}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="season">
          <AccordionTrigger className="text-sm font-semibold py-3">Season</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {seasons.map(season => (
                <div key={season} className="flex items-center space-x-2">
                  <Checkbox
                    id={`season-${season}`}
                    checked={selectedSeasons.includes(season)}
                    onCheckedChange={() => toggleSeason(season)}
                  />
                  <Label
                    htmlFor={`season-${season}`}
                    className="text-sm cursor-pointer"
                  >
                    {season}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="year">
          <AccordionTrigger className="text-sm font-semibold py-3">Year</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {years.map(year => (
                <div key={year} className="flex items-center space-x-2">
                  <Checkbox
                    id={`year-${year}`}
                    checked={selectedYears.includes(year)}
                    onCheckedChange={() => toggleYear(year)}
                  />
                  <Label
                    htmlFor={`year-${year}`}
                    className="text-sm cursor-pointer"
                  >
                    {year}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="status">
          <AccordionTrigger className="text-sm font-semibold py-3">Status</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {statuses.map(status => (
                <div key={status} className="flex items-center space-x-2">
                  <Checkbox
                    id={`status-${status}`}
                    checked={selectedStatus.includes(status)}
                    onCheckedChange={() => toggleStatus(status)}
                  />
                  <Label
                    htmlFor={`status-${status}`}
                    className="text-sm cursor-pointer"
                  >
                    {status}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

// Filter options data
const genres = [
  "Action", "Adventure", "Comedy", "Drama", "Fantasy",
  "Horror", "Mystery", "Romance", "Sci-Fi", "Slice of Life",
  "Sports", "Supernatural", "Thriller"
];

const formats = [
  "TV", "Movie", "OVA", "ONA", "Special"
];

const seasons = [
  "Winter", "Spring", "Summer", "Fall"
];

const years = [
  "2025", "2024", "2023", "2022", "2021", "2020", "2010s", "2000s", "1990s", "1980s"
];

const statuses = [
  "Releasing", "Finished", "Coming Soon", "Cancelled"
];

export default FilterSidebar;
