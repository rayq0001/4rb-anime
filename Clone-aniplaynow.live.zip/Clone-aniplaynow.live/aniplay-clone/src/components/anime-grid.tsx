"use client";

import Link from "next/link";
import Image from "next/image";
import { PlayCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const AnimeGrid = () => {
  // This would be fetched based on filters in a real app
  const animeList = [
    ...trendingAnime,
    ...popularThisSeason,
    ...mostFavorite,
    ...popularMovies,
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-medium">{animeList.length}</span> results
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Sort by:</span>
            <Select defaultValue="popularity">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Popularity</SelectItem>
                <SelectItem value="score">Score</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="oldest">Oldest</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {animeList.map((anime) => (
          <AnimeCard key={anime.id} anime={anime} />
        ))}
      </div>
    </div>
  );
};

interface Anime {
  id: string;
  title: string;
  image: string;
  type?: string;
  status?: string;
  episodes?: number;
  currentEpisode?: number;
  description?: string;
}

const AnimeCard = ({ anime }: { anime: Anime }) => {
  return (
    <Link href={`/anime/info/${anime.id}`} className="block">
      <Card className="bg-card border-0 overflow-hidden group anime-card-hover">
        <div className="relative">
          <AspectRatio ratio={3/4}>
            <Image
              src={anime.image}
              alt={anime.title}
              fill
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              className="object-cover rounded-t-md"
              priority={false}
            />
          </AspectRatio>

          {/* Overlay with play button on hover */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-200">
            <Button className="bg-purple-600 hover:bg-purple-700 text-white w-10 h-10 rounded-full p-0">
              <PlayCircle className="h-6 w-6" />
            </Button>
          </div>

          {/* Status Badge */}
          {anime.status && (
            <div className="absolute top-2 left-2">
              <Badge
                variant="outline"
                className={`text-xs font-medium ${
                  anime.status === "RELEASING"
                    ? "bg-green-500/20 text-green-300 border-green-800"
                    : anime.status === "FINISHED"
                    ? "bg-blue-500/20 text-blue-300 border-blue-800"
                    : "bg-yellow-500/20 text-yellow-300 border-yellow-800"
                }`}
              >
                {anime.status}
              </Badge>
            </div>
          )}

          {/* Episode Badge */}
          {anime.currentEpisode && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-purple-600 text-white text-xs">
                Ep {anime.currentEpisode}
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-3">
          <h3 className="font-semibold text-sm line-clamp-2">{anime.title}</h3>

          {/* Type and Episodes if available */}
          {(anime.type || anime.episodes) && (
            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
              {anime.type && <span>{anime.type}</span>}
              {anime.type && anime.episodes && <span>•</span>}
              {anime.episodes && <span>{anime.episodes} eps</span>}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
};

// Mock data for the grid
const trendingAnime = [
  {
    id: "21",
    title: "ONE PIECE",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 1129,
    currentEpisode: 1129
  },
  {
    id: "185213",
    title: "Mobile Suit Gundam GQuuuuuuX",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx185213-Pv7NliMfSLmk.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 25,
    currentEpisode: 7
  },
  {
    id: "174802",
    title: "The Shiunji Family Children",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx174802-rJORNTqw7eUB.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
];

const popularThisSeason = [
  {
    id: "149118",
    title: "Fire Force Season 3",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx149118-FlghR7T9KNfq.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
  {
    id: "167336",
    title: "LAZARUS",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx167336-6oMYQUm2LgXd.png",
    type: "TV",
    status: "RELEASING",
    episodes: 13,
    currentEpisode: 7
  },
  {
    id: "178680",
    title: "WIND BREAKER Season 2",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx178680-4mYUlJpBGjAw.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7
  },
];

const mostFavorite = [
  {
    id: "11061",
    title: "Hunter x Hunter (2011)",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx11061-sIpBprNRfzCe.png",
    type: "TV",
    status: "FINISHED",
    episodes: 148
  },
  {
    id: "16498",
    title: "Attack on Titan",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-C6FPmWm59CyP.jpg",
    type: "TV",
    status: "FINISHED",
    episodes: 25
  },
];

const popularMovies = [
  {
    id: "21519",
    title: "Your Name.",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
  {
    id: "20954",
    title: "A Silent Voice",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx20954-q0j9BNwr9yCX.jpg",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1
  },
];

export default AnimeGrid;
