import Link from "next/link";
import Image from "next/image";
import {
  HomeIcon,
  ListIcon,
  CalendarIcon,
  Music2Icon,
  SettingsIcon
} from "lucide-react";

const DiscordIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="9" cy="12" r="1"></circle>
    <circle cx="15" cy="12" r="1"></circle>
    <path d="M7.5 7.5c3.5-1 5.5-1 9 0"></path>
    <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
    <path d="M15.5 17c0 1 1.5 3 2 3 1.5 0 2.5-1.5 2.5-1.5l-1.5-2.5c-1 0-3 1-3 1z"></path>
    <path d="M8.5 17c0 1-1.5 3-2 3-1.5 0-2.5-1.5-2.5-1.5l1.5-2.5c1 0 3 1 3 1z"></path>
  </svg>
);

const Sidebar = () => {
  return (
    <aside className="sidebar h-screen bg-card fixed top-0 left-0 z-50 flex flex-col items-center py-6 overflow-hidden">
      <div className="mb-10">
        <Link href="/">
          <div className="w-10 h-10 relative">
            <Image
              src="/4rb-anime-logo.png"
              alt="4RB ANIME Logo"
              fill
              className="object-contain"
            />
          </div>
        </Link>
      </div>

      <nav className="flex flex-col items-center gap-8">
        <SidebarItem icon={<HomeIcon size={20} />} label="Home" path="/" />
        <SidebarItem icon={<ListIcon size={20} />} label="Catalog" path="/catalog" />
        <SidebarItem icon={<CalendarIcon size={20} />} label="Schedule" path="/schedule" />
        <SidebarItem icon={<Music2Icon size={20} />} label="Music" path="/music" />
        <SidebarItem icon={<SettingsIcon size={20} />} label="Settings" path="/settings" />
        <SidebarItem
          icon={<DiscordIcon />}
          label="Discord"
          path="https://discord.gg/jEqxrAmUZ4"
          external={true}
        />
      </nav>
    </aside>
  );
};

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  path: string;
  external?: boolean;
}

const SidebarItem = ({ icon, label, path, external = false }: SidebarItemProps) => {
  const content = (
    <div className="flex items-center gap-4 text-muted-foreground hover:text-foreground transition-colors duration-200">
      <div className="w-10 h-10 flex items-center justify-center">
        {icon}
      </div>
      <span className="whitespace-nowrap opacity-0 sidebar-hover:opacity-100 transition-opacity duration-200">
        {label}
      </span>
    </div>
  );

  if (external) {
    return (
      <a href={path} target="_blank" rel="noopener noreferrer">
        {content}
      </a>
    );
  }

  return (
    <Link href={path}>
      {content}
    </Link>
  );
};

export default Sidebar;
