import Image from "next/image";
import Link from "next/link";
import { PlayCircle, CalendarDays, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  // Featured anime data for hero section
  const featuredAnime = {
    id: "179955",
    title: "From Old Country Bumpkin to Master Swordsman",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/179955-RAGwCjbXLHkn.jpg",
    description: `Beryl Gardinant, a self-proclaimed humble old man, is a sword instructor at his dojo in a rural, backwater village. In his younger years, he dreamed of glory as a master swordsman, but those days are long behind him. Out of the blue, he receives a visit from a famous former pupil who brings him world-shattering news—he's been appointed as special instructor for the knights of the Liberion Order! With his life now turned upside down, Beryl travels to the capital and reunites with some of his former students: elite knights, an ace wizard, and even an adventurer who's attained the highest guild rank possible. But why do they all want his tutelage?! As far as he's concerned, they clearly don't need him anymore. Can Beryl live up to his new position? And will he ever get a moment's peace away from his adoring students?!`,
    status: "RELEASING",
    type: "TV",
    episodes: 12,
    currentEpisode: 7,
    releaseDate: "May 5, 2025"
  };

  return (
    <div className="relative w-full h-[600px] overflow-hidden rounded-xl">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-transparent z-10"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent z-10"></div>

      <Image
        src={featuredAnime.image}
        alt={featuredAnime.title}
        fill
        className="object-cover object-center"
        priority
      />

      {/* Content */}
      <div className="relative z-20 h-full flex flex-col justify-end p-8">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-purple-500/20 text-purple-300 px-2 py-1 text-xs rounded-md font-medium">
              #13 Trending
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold mb-4">{featuredAnime.title}</h1>

          <div className="flex items-center gap-6 mb-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-muted-foreground">
                <path d="M2 10C2 6.22876 2 4.34315 3.17157 3.17157C4.34315 2 6.22876 2 10 2H14C17.7712 2 19.6569 2 20.8284 3.17157C22 4.34315 22 6.22876 22 10V14C22 17.7712 22 19.6569 20.8284 20.8284C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.8284C2 19.6569 2 17.7712 2 14V10Z" stroke="currentColor" strokeWidth="1.5" />
                <path d="M16.5 14.5C16.5 15.8807 15.3807 17 14 17C12.6193 17 11.5 15.8807 11.5 14.5C11.5 13.1193 12.6193 12 14 12C15.3807 12 16.5 13.1193 16.5 14.5Z" stroke="currentColor" strokeWidth="1.5" />
                <path d="M7.5 9.5C7.5 10.8807 6.38071 12 5 12C3.61929 12 2.5 10.8807 2.5 9.5C2.5 8.11929 3.61929 7 5 7C6.38071 7 7.5 8.11929 7.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
                <path d="M16.5 9.5C16.5 10.8807 15.3807 12 14 12C12.6193 12 11.5 10.8807 11.5 9.5C11.5 8.11929 12.6193 7 14 7C15.3807 7 16.5 8.11929 16.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
                <path d="M11.5 9.5C11.5 10.8807 10.3807 12 9 12C7.61929 12 6.5 10.8807 6.5 9.5C6.5 8.11929 7.61929 7 9 7C10.3807 7 11.5 8.11929 11.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
              </svg>
              <span>TV</span>
            </div>
            <div className="flex items-center gap-2">
              <CalendarDays size={16} />
              <span>{featuredAnime.releaseDate}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={16} />
              <span>{featuredAnime.episodes} eps</span>
            </div>
          </div>

          <p className="text-sm text-muted-foreground mb-8 line-clamp-3">
            {featuredAnime.description}
          </p>

          <Link href={`/anime/info/${featuredAnime.id}`}>
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              <PlayCircle className="mr-2 h-4 w-4" />
              Watch Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
