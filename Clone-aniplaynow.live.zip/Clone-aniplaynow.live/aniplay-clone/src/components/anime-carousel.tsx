"use client";

import { useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { ChevronLeft, ChevronRight, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Badge } from "@/components/ui/badge";

interface Anime {
  id: string;
  title: string;
  image: string;
  type?: string;
  status?: string;
  episodes?: number;
  currentEpisode?: number;
  description?: string;
}

interface AnimeCarouselProps {
  title: string;
  animeList: Anime[];
}

const AnimeCarousel = ({ title, animeList }: AnimeCarouselProps) => {
  const carouselRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: -300, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: 300, behavior: "smooth" });
    }
  };

  return (
    <div className="relative">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold">{title}</h2>
        <div className="flex space-x-2">
          <Button
            onClick={scrollLeft}
            size="icon"
            variant="outline"
            className="rounded-full h-8 w-8"
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Scroll left</span>
          </Button>
          <Button
            onClick={scrollRight}
            size="icon"
            variant="outline"
            className="rounded-full h-8 w-8"
          >
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Scroll right</span>
          </Button>
        </div>
      </div>

      <div
        ref={carouselRef}
        className="carousel-container flex gap-4 pb-4 -mx-2 px-2"
      >
        {animeList.map((anime) => (
          <AnimeCard key={anime.id} anime={anime} />
        ))}
      </div>
    </div>
  );
};

const AnimeCard = ({ anime }: { anime: Anime }) => {
  return (
    <Link href={`/anime/info/${anime.id}`} className="block">
      <Card className="w-[220px] bg-card border-0 overflow-hidden group anime-card-hover">
        <div className="relative">
          <AspectRatio ratio={3/4}>
            <Image
              src={anime.image}
              alt={anime.title}
              fill
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              className="object-cover rounded-t-md"
              priority={false}
            />
          </AspectRatio>

          {/* Overlay with play button on hover */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-200">
            <Button className="bg-purple-600 hover:bg-purple-700 text-white w-10 h-10 rounded-full p-0">
              <PlayCircle className="h-6 w-6" />
            </Button>
          </div>

          {/* Status Badge */}
          {anime.status && (
            <div className="absolute top-2 left-2">
              <Badge
                variant="outline"
                className={`text-xs font-medium ${
                  anime.status === "RELEASING"
                    ? "bg-green-500/20 text-green-300 border-green-800"
                    : anime.status === "FINISHED"
                    ? "bg-blue-500/20 text-blue-300 border-blue-800"
                    : "bg-yellow-500/20 text-yellow-300 border-yellow-800"
                }`}
              >
                {anime.status}
              </Badge>
            </div>
          )}

          {/* Episode Badge */}
          {anime.currentEpisode && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-purple-600 text-white text-xs">
                Ep {anime.currentEpisode}
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-3">
          <h3 className="font-semibold text-sm line-clamp-2">{anime.title}</h3>

          {/* Type and Episodes if available */}
          {(anime.type || anime.episodes) && (
            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
              {anime.type && <span>{anime.type}</span>}
              {anime.type && anime.episodes && <span>•</span>}
              {anime.episodes && <span>{anime.episodes} eps</span>}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
};

export default AnimeCarousel;
