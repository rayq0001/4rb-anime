import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PlayCircle, Calendar, Clock, Star, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AnimeCarousel from "@/components/anime-carousel";

interface PageProps {
  params: { id: string };
  searchParams?: { [key: string]: string | string[] | undefined };
}

export default function AnimeDetailPage({ params }: PageProps) {
  // In a real app, this would fetch from an API
  const anime = allAnime.find(item => item.id === params.id);

  if (!anime) {
    notFound();
  }

  return (
    <div className="container mx-auto pt-2 pl-16 max-w-full">
      {/* Hero Banner */}
      <div className="relative w-full h-[400px] overflow-hidden rounded-xl mb-8">
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-transparent z-10"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent z-10"></div>

        <Image
          src={anime.bannerImage || anime.image}
          alt={anime.title}
          fill
          className="object-cover object-center"
          priority
        />

        {/* Content Overlay */}
        <div className="relative z-20 h-full flex items-end p-8">
          <div className="flex gap-8">
            <div className="hidden sm:block w-[200px] h-[300px] relative rounded-lg overflow-hidden shadow-xl border-4 border-background">
              <Image
                src={anime.image}
                alt={anime.title}
                fill
                className="object-cover"
              />
            </div>

            <div className="flex flex-col justify-end">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{anime.title}</h1>

              <div className="flex flex-wrap gap-2 mb-4">
                {anime.genres?.map(genre => (
                  <Badge key={genre} variant="outline" className="bg-primary/10">
                    {genre}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center gap-6 mb-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-muted-foreground">
                    <path d="M2 10C2 6.22876 2 4.34315 3.17157 3.17157C4.34315 2 6.22876 2 10 2H14C17.7712 2 19.6569 2 20.8284 3.17157C22 4.34315 22 6.22876 22 10V14C22 17.7712 22 19.6569 20.8284 20.8284C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.8284C2 19.6569 2 17.7712 2 14V10Z" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M16.5 14.5C16.5 15.8807 15.3807 17 14 17C12.6193 17 11.5 15.8807 11.5 14.5C11.5 13.1193 12.6193 12 14 12C15.3807 12 16.5 13.1193 16.5 14.5Z" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M7.5 9.5C7.5 10.8807 6.38071 12 5 12C3.61929 12 2.5 10.8807 2.5 9.5C2.5 8.11929 3.61929 7 5 7C6.38071 7 7.5 8.11929 7.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M16.5 9.5C16.5 10.8807 15.3807 12 14 12C12.6193 12 11.5 10.8807 11.5 9.5C11.5 8.11929 12.6193 7 14 7C15.3807 7 16.5 8.11929 16.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M11.5 9.5C11.5 10.8807 10.3807 12 9 12C7.61929 12 6.5 10.8807 6.5 9.5C6.5 8.11929 7.61929 7 9 7C10.3807 7 11.5 8.11929 11.5 9.5Z" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                  <span>{anime.type}</span>
                </div>

                {anime.releaseDate && (
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>{anime.releaseDate}</span>
                  </div>
                )}

                {anime.episodes && (
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>{anime.episodes} eps</span>
                  </div>
                )}

                {anime.score && (
                  <div className="flex items-center gap-2">
                    <Star size={16} className="fill-yellow-500 text-yellow-500" />
                    <span className="font-medium text-yellow-500">{anime.score}</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-3">
                {anime.status === "RELEASING" && (
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    <PlayCircle className="mr-2 h-4 w-4" />
                    Watch Now
                  </Button>
                )}

                <Button variant="outline">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="overview" className="mb-8">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="episodes">Episodes</TabsTrigger>
              <TabsTrigger value="characters">Characters</TabsTrigger>
              <TabsTrigger value="staff">Staff</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="bg-card rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Synopsis</h2>
                <p className="text-muted-foreground">{anime.description}</p>

                {/* Information Section */}
                <div className="mt-8">
                  <h3 className="text-lg font-semibold mb-4">Information</h3>
                  <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-8">
                    <div>
                      <dt className="text-sm text-muted-foreground">Format</dt>
                      <dd className="text-sm">{anime.type}</dd>
                    </div>

                    <div>
                      <dt className="text-sm text-muted-foreground">Episodes</dt>
                      <dd className="text-sm">{anime.episodes}</dd>
                    </div>

                    <div>
                      <dt className="text-sm text-muted-foreground">Status</dt>
                      <dd className="text-sm">{anime.status}</dd>
                    </div>

                    <div>
                      <dt className="text-sm text-muted-foreground">Season</dt>
                      <dd className="text-sm">{anime.season} {anime.seasonYear}</dd>
                    </div>

                    {anime.studios && (
                      <div>
                        <dt className="text-sm text-muted-foreground">Studios</dt>
                        <dd className="text-sm">{anime.studios}</dd>
                      </div>
                    )}

                    {anime.source && (
                      <div>
                        <dt className="text-sm text-muted-foreground">Source</dt>
                        <dd className="text-sm">{anime.source}</dd>
                      </div>
                    )}
                  </dl>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="episodes" className="mt-6">
              <div className="bg-card rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Episodes</h2>

                <div className="space-y-4">
                  {Array(anime.episodes || 12).fill(0).map((_, idx) => (
                    <div key={idx} className="flex gap-4 p-3 hover:bg-primary/5 rounded-lg transition-colors">
                      <div className="relative w-[180px] h-[100px] overflow-hidden rounded-md bg-muted">
                        <Image
                          src={anime.image}
                          alt={`Episode ${idx + 1}`}
                          fill
                          className="object-cover"
                        />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">Episode {idx + 1}</h3>
                        <p className="text-sm text-muted-foreground mb-2">Episode Title</p>
                        <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
                          <PlayCircle className="mr-2 h-3 w-3" />
                          Watch
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="characters" className="mt-6">
              <div className="bg-card rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Characters</h2>
                <p className="text-muted-foreground">Character information would be displayed here.</p>
              </div>
            </TabsContent>

            <TabsContent value="staff" className="mt-6">
              <div className="bg-card rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Staff</h2>
                <p className="text-muted-foreground">Staff information would be displayed here.</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <div className="bg-card rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Related Anime</h2>
            <div className="space-y-4">
              {/* This would be actual related anime in a real app */}
              {relatedAnime.slice(0, 3).map(anime => (
                <div key={anime.id} className="flex gap-3">
                  <div className="w-[80px] h-[120px] relative overflow-hidden rounded-md">
                    <Image
                      src={anime.image}
                      alt={anime.title}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div className="flex-1">
                    <Link href={`/anime/info/${anime.id}`}>
                      <h3 className="font-semibold text-sm hover:text-primary transition-colors line-clamp-2 mb-1">
                        {anime.title}
                      </h3>
                    </Link>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{anime.type}</span>
                      <span>•</span>
                      <span>{anime.status}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Recommendations</h2>
            <div className="space-y-4">
              {/* This would be actual recommendations in a real app */}
              {popularMovies.slice(0, 3).map(anime => (
                <div key={anime.id} className="flex gap-3">
                  <div className="w-[80px] h-[120px] relative overflow-hidden rounded-md">
                    <Image
                      src={anime.image}
                      alt={anime.title}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div className="flex-1">
                    <Link href={`/anime/info/${anime.id}`}>
                      <h3 className="font-semibold text-sm hover:text-primary transition-colors line-clamp-2 mb-1">
                        {anime.title}
                      </h3>
                    </Link>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{anime.type}</span>
                      <span>•</span>
                      <span>{anime.status}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Similar Anime Carousel */}
      <div className="mt-16">
        <AnimeCarousel
          title="You May Also Like"
          animeList={[...popularThisSeason, ...popularMovies].slice(0, 6)}
        />
      </div>
    </div>
  );
}

// Mock data for anime details
// In a real app, these would be fetched from an API
const trendingAnime = [
  {
    id: "21",
    title: "ONE PIECE",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx21-tXMN3Y20PIL9.jpg",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/21-wf37VakJmZqs.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 1129,
    currentEpisode: 1129,
    season: "SPRING",
    seasonYear: 1999,
    genres: ["Action", "Adventure", "Comedy", "Drama", "Fantasy"],
    studios: "Toei Animation",
    source: "Manga",
    description: "Gol D. Roger was known as the Pirate King, the strongest and most infamous being to have sailed the Grand Line. The capture and death of Roger by the World Government brought a change throughout the world. His last words before his death revealed the location of the greatest treasure in the world, One Piece. It was this revelation that brought about the Grand Age of Pirates, men who dreamed of finding One Piece (which promises an unlimited amount of riches and fame), and quite possibly the most coveted of titles for the person who found it, the title of the Pirate King.\n\nEnter Monkey D. Luffy, a 17-year-old boy that defies your standard definition of a pirate. Rather than the popular persona of a wicked, hardened, toothless pirate who ransacks villages for fun, Luffy's reason for being a pirate is one of pure wonder; the thought of an exciting adventure and meeting new and intriguing people, along with finding One Piece, are his reasons of becoming a pirate. Following in the footsteps of his childhood hero, Luffy and his crew travel across the Grand Line, experiencing crazy adventures, unveiling dark mysteries and battling strong enemies, all in order to reach One Piece.",
    score: 8.4,
    releaseDate: "Oct 20, 1999"
  },
  {
    id: "179955",
    title: "From Old Country Bumpkin to Master Swordsman",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx179955-HZ4TrxnPpRl9.jpg",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/179955-RAGwCjbXLHkn.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7,
    season: "SPRING",
    seasonYear: 2025,
    genres: ["Action", "Adventure", "Comedy", "Fantasy"],
    studios: "BLADE",
    source: "Light Novel",
    description: "Beryl Gardinant, a self-proclaimed humble old man, is a sword instructor at his dojo in a rural, backwater village. In his younger years, he dreamed of glory as a master swordsman, but those days are long behind him. Out of the blue, he receives a visit from a famous former pupil who brings him world-shattering news—he's been appointed as special instructor for the knights of the Liberion Order! With his life now turned upside down, Beryl travels to the capital and reunites with some of his former students: elite knights, an ace wizard, and even an adventurer who's attained the highest guild rank possible. But why do they all want his tutelage?! As far as he's concerned, they clearly don't need him anymore. Can Beryl live up to his new position? And will he ever get a moment's peace away from his adoring students?!",
    score: 7.8,
    releaseDate: "May 5, 2025"
  },
];

const popularThisSeason = [
  {
    id: "149118",
    title: "Fire Force Season 3",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx149118-FlghR7T9KNfq.jpg",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/149118-egLSsCDdp9Z0.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 12,
    currentEpisode: 7,
    season: "SPRING",
    seasonYear: 2025,
    genres: ["Action", "Drama", "Supernatural"],
    studios: "David Production",
    source: "Manga",
    description: "Third season of Enen no Shouboutai.",
    score: 8.2,
    releaseDate: "May 2, 2025"
  },
  {
    id: "167336",
    title: "LAZARUS",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx167336-6oMYQUm2LgXd.png",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/167336-EH10H0cSlzUX.jpg",
    type: "TV",
    status: "RELEASING",
    episodes: 13,
    currentEpisode: 7,
    season: "SPRING",
    seasonYear: 2025,
    genres: ["Action", "Drama", "Mystery", "Sci-Fi", "Thriller"],
    studios: "CloverWorks, WIT Studio",
    source: "Original",
    description: "A century after the world was nearly destroyed, dangerous viruses are being used as weapons against humanity. In an ever-worsening pandemic, the Lazarus Project sends their iconic agent Mia into battle to protect a young woman named Hisako, who may be the key that humanity needs to survive.",
    score: 8.3,
    releaseDate: "April 2, 2025"
  },
];

const popularMovies = [
  {
    id: "21519",
    title: "Your Name.",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PeczUjjF.png",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/21519-1ayMXxGrNWKj.jpg",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1,
    season: "SUMMER",
    seasonYear: 2016,
    genres: ["Drama", "Romance", "Supernatural"],
    studios: "CoMix Wave Films",
    source: "Original",
    description: "Mitsuha Miyamizu, a high school girl, yearns to live the life of a boy in the bustling city of Tokyo—a dream that stands in stark contrast to her present life in the countryside. Meanwhile in the city, Taki Tachibana lives a busy life as a high school student while juggling his part-time job and hopes for a future in architecture.\n\nOne day, Mitsuha awakens in a room that is not her own and suddenly finds herself living the dream life in Tokyo—but in Taki's body! Elsewhere, Taki finds himself living Mitsuha's life in the humble countryside. In pursuit of an answer to this strange phenomenon, they begin to search for one another.\n\nKimi no Na wa. revolves around Mitsuha and Taki's actions, which begin to have a dramatic impact on each other's lives, weaving them into a fabric held together by fate and circumstance.",
    score: 8.8,
    releaseDate: "Aug 26, 2016"
  },
  {
    id: "20954",
    title: "A Silent Voice",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/nx20954-q0j9BNwr9yCX.jpg",
    bannerImage: "https://s4.anilist.co/file/anilistcdn/media/anime/banner/20954-f30baqtBi5TZ.jpg",
    type: "MOVIE",
    status: "FINISHED",
    episodes: 1,
    season: "FALL",
    seasonYear: 2016,
    genres: ["Drama", "Romance", "Slice of Life"],
    studios: "Kyoto Animation",
    source: "Manga",
    description: "After transferring into a new school, a deaf girl, Shouko Nishimiya, is bullied by the popular Shouya Ishida. As Shouya continues to bully Shouko, the class turns its back on him. Shouko transfers and Shouya grows up as an outcast. Alone and depressed, the regretful Shouya finds Shouko to make amends.\n\n(Source: Eleven Arts)",
    score: 8.9,
    releaseDate: "Sep 17, 2016"
  },
];

const relatedAnime = [
  {
    id: "104578",
    title: "Attack on Titan Season 3 Part 2",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx104578-LaZYFkmhinfB.jpg",
    type: "TV",
    status: "FINISHED",
    episodes: 10
  },
  {
    id: "146984",
    title: "Demon Slayer: Kimetsu no Yaiba Entertainment District Arc",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx146984-EvXoHqtNaANt.jpg",
    type: "TV",
    status: "FINISHED",
    episodes: 11
  },
  {
    id: "151807",
    title: "Chainsaw Man",
    image: "https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx127230-FlochcFsyoF4.png",
    type: "TV",
    status: "FINISHED",
    episodes: 12
  }
];

// Combine all anime data for lookup
const allAnime = [
  ...trendingAnime,
  ...popularThisSeason,
  ...popularMovies,
  ...relatedAnime
];
