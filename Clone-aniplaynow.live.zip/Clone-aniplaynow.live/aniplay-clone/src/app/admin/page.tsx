import AdminDashboard from "./admin-dashboard";

export default function AdminPage() {
  return <AdminDashboard />;
}
