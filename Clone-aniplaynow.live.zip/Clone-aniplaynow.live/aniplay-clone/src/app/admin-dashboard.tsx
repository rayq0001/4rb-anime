import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface User {
  id: number;
  username: string;
  role: "admin" | "staff";
  email: string;
}

interface ScraperStatus {
  running: boolean;
  lastRun: string;
  logs: string[];
}

interface Comment {
  id: number;
  content: string;
  user: string;
  approved: boolean;
}

interface StaffRating {
  staffId: number;
  rating: number;
  comment: string;
}

interface Anime {
  id: number;
  title: string;
  description: string;
  image: string;
  approved: boolean;
}

function useAuth() {
  return { user: { role: 'admin' }, status: 'authenticated' };
}

export default function AdminDashboard() {
  const { user, status } = useAuth();
  if (status !== 'authenticated' || !['admin', 'staff'].includes(user.role)) {
    return <div className="p-6">غير مصرح لك بعرض لوحة التحكم. الرجاء تسجيل الدخول بحساب ستاف أو أدمن.</div>;
  }

  const [users, setUsers] = useState<User[]>([]);
  const [scraperStatus, setScraperStatus] = useState<ScraperStatus>({
    running: false,
    lastRun: "",
    logs: []
  });
  const [comments, setComments] = useState<Comment[]>([]);
  const [ratings, setRatings] = useState<StaffRating[]>([]);
  const [animes, setAnimes] = useState<Anime[]>([]);
  const [newUser, setNewUser] = useState({ username: "", email: "", password: "", role: "staff" });
  const currentUserRole = "admin"; // تمثيل صلاحية المستخدم الحالي مؤقتاً

  useEffect(() => {
    fetch("/api/users").then(res => res.json()).then(data => setUsers(data));
    fetch("/api/scraper/status").then(res => res.json()).then(data => setScraperStatus(data));
    fetch("/api/comments").then(res => res.json()).then(data => setComments(data));
    fetch("/api/ratings").then(res => res.json()).then(data => setRatings(data));
    fetch("/api/animes/pending").then(res => res.json()).then(data => setAnimes(data));
  }, []);

  const addUser = async () => {
    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser),
    });
    const data = await res.json();
    setUsers([...users, data]);
    setNewUser({ username: "", email: "", password: "", role: "staff" });
  };

  const toggleScraper = async () => {
    const res = await fetch("/api/scraper/toggle", { method: "POST" });
    const data = await res.json();
    setScraperStatus(data);
  };

  const approveComment = async (id: number) => {
    await fetch(`/api/comments/${id}/approve`, { method: "POST" });
    setComments(comments.map(c => c.id === id ? { ...c, approved: true } : c));
  };

  const approveAnime = async (id: number) => {
    await fetch(`/api/animes/${id}/approve`, { method: "POST" });
    setAnimes(animes.map(a => a.id === id ? { ...a, approved: true } : a));
  };

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold">لوحة التحكم</h1>

      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">معلومات المستخدمين</h2>
          <ul>
            {users.map(user => (
              <li key={user.id} className="border-b py-2">
                {user.username} ({user.email}) - <strong>{user.role}</strong>
              </li>
            ))}
          </ul>
          <div className="flex gap-2">
            <Input
              placeholder="اسم المستخدم"
              value={newUser.username}
              onChange={e => setNewUser({ ...newUser, username: e.target.value })}
            />
            <Input
              placeholder="البريد الإلكتروني"
              value={newUser.email}
              onChange={e => setNewUser({ ...newUser, email: e.target.value })}
            />
            <Input
              placeholder="كلمة المرور"
              type="password"
              value={newUser.password}
              onChange={e => setNewUser({ ...newUser, password: e.target.value })}
            />
            <select
              value={newUser.role}
              onChange={e => setNewUser({ ...newUser, role: e.target.value as 'admin' | 'staff' })}
              className="border rounded px-2"
            >
              <option value="staff">ستاف</option>
              <option value="admin">أدمن</option>
            </select>
            <Button onClick={addUser}>إضافة</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">وضع السكربت</h2>
          <p>
            الحالة: {scraperStatus.running ? "يعمل الآن" : "متوقف"} <br />
            آخر تشغيل: {scraperStatus.lastRun}
          </p>
          <Button onClick={toggleScraper}>
            {scraperStatus.running ? "إيقاف السكربت" : "تشغيل السكربت"}
          </Button>
          <div>
            <h3 className="font-medium mt-4">سجل العمليات:</h3>
            <ul className="bg-gray-100 p-2 rounded max-h-40 overflow-auto text-sm">
              {scraperStatus.logs.map((log, idx) => (
                <li key={idx}>{log}</li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">مراجعة التعليقات</h2>
          <ul>
            {comments.map(comment => (
              <li key={comment.id} className="border-b py-2">
                <strong>{comment.user}:</strong> {comment.content} -
                {comment.approved ? " تمت الموافقة " : (
                  <Button className="ml-2" onClick={() => approveComment(comment.id)}>
                    الموافقة
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {currentUserRole === "admin" && (
        <>
          <Card>
            <CardContent className="space-y-4">
              <h2 className="text-xl font-semibold">تقييم الستاف</h2>
              <ul>
                {ratings.map((rating, idx) => (
                  <li key={idx} className="border-b py-2">
                    <strong>ستاف ID:</strong> {rating.staffId} | تقييم: {rating.rating}/5<br />
                    <em>{rating.comment}</em>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-4">
              <h2 className="text-xl font-semibold">مراجعة الأنميات</h2>
              <ul>
                {animes.map(anime => (
                  <li key={anime.id} className="border-b py-4 flex items-start gap-4">
                    <img src={anime.image} alt={anime.title} className="w-24 h-32 object-cover rounded" />
                    <div>
                      <h3 className="text-lg font-bold">{anime.title}</h3>
                      <p className="text-sm text-gray-600">{anime.description}</p>
                      {!anime.approved && (
                        <Button className="mt-2" onClick={() => approveAnime(anime.id)}>
                          الموافقة على الأنمي
                        </Button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
