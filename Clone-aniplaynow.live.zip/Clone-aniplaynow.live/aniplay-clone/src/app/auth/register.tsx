import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    // TODO: Implement registration logic (call /api/auth/register)
    setTimeout(() => {
      setLoading(false);
      setError("Registration not implemented.");
    }, 1000);
  };

  const handleProvider = (provider: string) => {
    // TODO: Implement OAuth register/login redirect (Google/Discord)
    alert(`Redirect to ${provider} signup`);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <Card className="w-full max-w-md">
        <CardContent className="p-8 space-y-6">
          <h1 className="text-2xl font-bold text-center">تسجيل حساب جديد</h1>
          <form className="space-y-4" onSubmit={handleRegister}>
            <Input
              type="text"
              placeholder="اسم المستخدم"
              value={username}
              onChange={e => setUsername(e.target.value)}
              required
            />
            <Input
              type="email"
              placeholder="البريد الإلكتروني"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <Input
              type="password"
              placeholder="كلمة المرور"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "...جاري التسجيل" : "تسجيل"}
            </Button>
          </form>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-px bg-gray-200" />
            <span className="text-xs text-gray-400">أو</span>
            <div className="flex-1 h-px bg-gray-200" />
          </div>
          <Button variant="outline" className="w-full flex items-center gap-2" onClick={() => handleProvider('google')}>
            <img src="/google.svg" alt="Google" className="w-5 h-5" />
            التسجيل عبر Google
          </Button>
          <Button variant="outline" className="w-full flex items-center gap-2" onClick={() => handleProvider('discord')}>
            <img src="/discord.svg" alt="Discord" className="w-5 h-5" />
            التسجيل عبر Discord
          </Button>
          <div className="text-center text-sm mt-4">
            لديك حساب؟ <a href="/auth/login" className="text-primary underline">سجّل الدخول</a>
          </div>
          {error && <div className="text-red-500 text-center text-sm">{error}</div>}
        </CardContent>
      </Card>
    </div>
  );
}
