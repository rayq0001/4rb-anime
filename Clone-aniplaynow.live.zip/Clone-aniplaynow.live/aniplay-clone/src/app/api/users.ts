import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { promises as fs } from "fs";
import path from "path";

const USERS_FILE = path.join(process.cwd(), "src/app/api/users.json");

async function readUsers() {
  try {
    const data = await fs.readFile(USERS_FILE, "utf-8");
    return JSON.parse(data);
  } catch {
    return [];
  }
}

async function writeUsers(users: any[]) {
  await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), "utf-8");
}

// On first run, hash the password if not already hashed
(async () => {
  let users = await readUsers();
  if (users.length === 0) {
    return;
  }
  if (users[0].password.startsWith('Ax3212321@')) {
    users[0].password = await bcrypt.hash(users[0].password, 10);
    await writeUsers(users);
  }
})();

export const runtime = "nodejs";

export async function GET() {
  const users = await readUsers();
  return NextResponse.json(users.map(({ password, ...rest }: any) => rest));
}

export async function POST(req: Request) {
  const { username, email, password, role } = await req.json();
  if (!username || !email || !password || !role) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }
  let users = await readUsers();
  if (users.some((u: any) => u.email === email)) {
    return NextResponse.json({ error: "User already exists" }, { status: 409 });
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = {
    id: users.length ? Math.max(...users.map((u: any) => u.id)) + 1 : 1,
    username,
    email,
    password: hashedPassword,
    role,
  };
  users.push(newUser);
  await writeUsers(users);
  const { password: _, ...userWithoutPassword } = newUser;
  return NextResponse.json(userWithoutPassword);
}
