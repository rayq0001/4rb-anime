import { NextResponse } from 'next/server';
import { extractSiteData } from '@/lib/extract-site-data';
import { status } from '../status/route';

export async function POST() {
  if (status.running) {
    // Stop the scraper
    status.running = false;
    status.logs.push('Scraper stopped by user');
    return NextResponse.json(status);
  } else {
    // Start the scraper
    status.running = true;
    status.startedAt = Date.now();
    status.logs.push('Scraper started');
    status.lastRun = new Date().toISOString();
    // Run scraper in background
    extractSiteData({
      onLog: (msg) => status.logs.push(msg),
      onStop: () => !status.running,
    }).then(() => {
      status.running = false;
      status.logs.push('Scraper finished');
    });
    return NextResponse.json(status);
  }
}
