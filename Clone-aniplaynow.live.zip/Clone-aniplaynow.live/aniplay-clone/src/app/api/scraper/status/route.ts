import { NextResponse } from 'next/server';

// In-memory status (replace with DB or file for persistence)
let status = {
  running: false,
  lastRun: '',
  logs: [],
  duration: 0,
  startedAt: null,
};

export function getScraperStatus() {
  if (status.running && status.startedAt) {
    status.duration = Math.floor((Date.now() - status.startedAt) / 1000);
  }
  return status;
}

export async function GET() {
  return NextResponse.json(getScraperStatus());
}

// Export for use in toggle route
export { status };
